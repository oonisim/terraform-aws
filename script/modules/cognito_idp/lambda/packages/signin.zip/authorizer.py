"""
API Gateway custom authorizer to handle authenticate/authorize the user with the token provided.


"""

