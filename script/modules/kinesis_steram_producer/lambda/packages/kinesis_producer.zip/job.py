JOB_STATUS_CREATED      = "created"
JOB_STATUS_STARTED      = "started"
JOB_STATUS_ABORTED      = "aborted"
JOB_STATUS_ENDED        = "ended"
JOB_STATUS_ZOMBI        = "zombi"

JOB_DELIMITER           = "_"