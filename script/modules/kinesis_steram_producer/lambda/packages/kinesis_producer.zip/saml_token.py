#--------------------------------------------------------------------------------
# Decode SAML Assertion
#--------------------------------------------------------------------------------
from __future__ import print_function

def decode(token) :
    print("Not yet implemented")
    return None