"""
Lambda function to generate a web page to upload the file for a job execution.
"""
from __future__ import print_function

import sys
import os
import traceback

import utility
import decoder
import presign
import web
import db

# --------------------------------------------------------------------------------
# Terrafrm Interpolation
# --------------------------------------------------------------------------------
REGION = "us-east-1"  # S3 bucket region
BUCKET = "riotinto-rtx-project-inversion-data"  # S3 bucket for pre-sign
EXPIRY = "7200"  # Pre-sign expiration period in sec

# --------------------------------------------------------------------------------
# Utility
# --------------------------------------------------------------------------------
def logger():
    """ Provide logger instance
    Return: logger instance
    """
    if not hasattr(logger, 'instance'):
        logger.instance = utility.get_logger(__file__)

    return logger.instance

def log_debug(message):
    """Log debug messages
    Args: debug message
    Returns: void
    """
    logger().debug("--------------------------------------------------------------------------------")
    logger().debug("In file [%s]", os.path.basename(__file__))
    logger().debug(message)

def log_exception(exception):
    """ Provide exception detail and stack trace.
    :Args:
        exception: Exception
    Returns: void
    """
    logger().error("--------------------------------------------------------------------------------")
    logger().error("In file [%s]", os.path.basename(__file__))
    logger().error("Exception [%s] [%s]", type(exception), exception.message)
    logger().error(traceback.format_exc())
    logger().error("--------------------------------------------------------------------------------")

def pretty_json(dictionary):
    """Generate formatted JSON
    Args: Python dictionary
    Returns: Formatted JSON
    """
    return utility.pretty_json(dictionary)

# --------------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------------
def main(token):
    """Generate a web page to upload the input file for the job.

    1. Decode the token to get user claims in the JSON format
       {
         "uid"      : "<user identity>"
         "email"    : "<user email>"        Required to notify the user.
         "auth_time": "<epoch time>"        Time the token is created
         "expiry"   : "<epoch time>"        Time when the token expires.
       }

    2. Create an record in the job table using the user claims.
       The job ID is the key and used as the S3 directory for the job.
       Hence the S3 directory identifies the job too.
    3. Create a S3 pre-signed URL to upload the job input file.

    Args:
        token: A token such as SAML assertion which identifies the user.

    Returns:
        web page to upload the input file to the S3 presigned URL.
    """
    try:
        claims = decoder.decode(token)
    except RuntimeError as exception:
        page = """
            <html><body>
            Lambda execution failed at token decoding for {0}
            </body></html>
        """
        return {
            "status_code": 500,
            "page": page.format(exception.message)
        }

    try:
        record = db.create(claims)
        job_id = record['id']
        page = web.generate_upload_page(presign.url(REGION, BUCKET, job_id, EXPIRY))
        return {
            "status_code": 200,
            "page": page
        }
    except RuntimeError as exception:
        page = """
            <html><body>
            Lambda execution failed at database for {0}
            </body></html>
        """
        return {
            "status_code": 500,
            "page": page.format(exception.message)
        }


def lambda_response(response):
    """ Generate the response format that the AWS lambda service expects.
    Args:
        response: {
            "status_code": code,
            "page": web_page
        }

    Returns:
        Lambda response as the web contents in the body.
    """
    return {
        "statusCode": response['status_code'],
        "headers": {
            "Content-Type": "text/html"
        },
        "body": response['page'],
        "isBase64Encoded": False
    }

def lambda_handler(event, context):
    """AWS lambda to generate a web page to upload the job input file
    Expected Lambda Integration type is AWS_PROXY (Lambda Proxy Integration)

    Args:
        event: Lambda event 
        context: Lambda context 

    Returns:
        Web page to upload the input file.
    """
    log_debug("Lambda event = [" + pretty_json(event) + "]")
    try:
        headers = event['headers']
        token = headers['Authorization']
        log_debug("Authorization token = [" + token + "]")

        response = main(token)
        return lambda_response(response)

    except Exception as exception:
        page = """
            <html><body>
            Lambda execution failed for {0}.
            </body></html>
        """
        logger().error("Lambda [%s]: execution failed", os.path.basename(__file__))
        log_exception(exception)

        response = {
            "status_code": 500,
            "page": page.format(exception.message)
        }
        return lambda_response(response)

def test():
    """Unit test main
    """
    print("token?")
    cognito_id_token = sys.stdin.readline().rstrip('\n')
    event = {
        "headers": {
            "Authorization": cognito_id_token,
            "Content-Type": "text/plain",
            "Via": "1.1 470917b83663a136083f105e2fd03290.cloudfront.net (CloudFront)",
            "CloudFront-Is-Desktop-Viewer": "true",
            "CloudFront-Is-SmartTV-Viewer": "false",
            "CloudFront-Forwarded-Proto": "https",
            "X-Forwarded-For": "59.100.168.81, 54.239.202.62",
            "CloudFront-Viewer-Country": "AU",
            "Accept": "*/*",
            "User-Agent": "PostmanRuntime/7.2.0",
            "X-Amzn-Trace-Id": "Root=1-5b922744-dc9ea90ce9533203a3de5f09",
            "X-Forwarded-Port": "443",
            "Host": "48hdhmryaf.execute-api.us-east-1.amazonaws.com",
            "X-Forwarded-Proto": "https",
            "X-Amz-Cf-Id": "gnK9QB7F0DctATpizImviEY71Xl8DpwauJrfrYs158bqCPW_4X54ag==",
            "CloudFront-Is-Tablet-Viewer": "false",
            "cache-control": "no-cache",
            "Postman-Token": "2f53c05a-578f-4e5f-bcc3-a0b064ba2a80",
            "CloudFront-Is-Mobile-Viewer": "false",
            "Accept-Encoding": "gzip, deflate"
        },
    }
    response = lambda_handler(event, None)
    print(utility.pretty_json(response))


if __name__ == '__main__':
    test()
