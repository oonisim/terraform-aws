import base64
import boto3
import hashlib
import hmac

UserPoolId = "us-east-1_5loxLzlwv"
AppClientId = "3tjdt39cq4lodrn60kjmsbv3jq"
AppClientSecret = "1h30i3saj27rivejtpccn4it19obkjs0318tcufvnngd5jkmd3fm"
Username = "masayuki.onishi@riotinto.com"
Password = "P@ssword"

Signature = hmac.new(AppClientSecret, Username+AppClientId, digestmod=hashlib.sha256)
Hash = base64.b64encode(Signature.digest())

Cognito = boto3.client("cognito-idp")

AuthResponse = Cognito.admin_initiate_auth(
    AuthFlow="ADMIN_NO_SRP_AUTH",
    ClientId=AppClientId,
    UserPoolId=UserPoolId,
    AuthParameters={"USERNAME":Username, "PASSWORD":Password, "SECRET_HASH":Hash})

IdToken = AuthResponse["AuthenticationResult"]["IdToken"]
RefreshToken = AuthResponse["AuthenticationResult"]["RefreshToken"]

RefreshResponse = Cognito.admin_initiate_auth(
    AuthFlow="REFRESH_TOKEN_AUTH",
    ClientId=AppClientId,
    UserPoolId=UserPoolId,
    AuthParameters={"REFRESH_TOKEN":RefreshToken, "SECRET_HASH":Hash})

NewIdToken = RefreshResponse["AuthenticationResult"]["IdToken"]