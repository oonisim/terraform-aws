#!/usr/bin/env bash
#--------------------------------------------------------------------------------
# Setup the lambda requirements
#--------------------------------------------------------------------------------
# To be replaced with PyJWT or jwt (python3)
pip install python-jose -t .
#pip install cryptography -t .
#pip install PyJWT -t .
