import base64
import boto3
import hashlib
import hmac

USER_POOL_ID = "us-east-1_5loxLzlwv"
CLIENT_ID = "3tjdt39cq4lodrn60kjmsbv3jq"
CLIENT_SECRET = "1h30i3saj27rivejtpccn4it19obkjs0318tcufvnngd5jkmd3fm"
USERNAME = "masayuki.onishi@riotinto.com"
PASSWORD = "P@ssword"

# --------------------------------------------------------------------------------
# Cognito
# --------------------------------------------------------------------------------
def get_client():
    """EC2 resource accessor

    Returns:
        Boto3 EC2 client
    """
    if not hasattr(get_client, "client"):
        setattr(get_client, "client", boto3.client('cognito-idp', region_name='us-east-1'))
        assert(getattr(get_client, "client") is not None)

    return getattr(get_client, "client")

def get_secret_hash(username):
    msg = username + CLIENT_ID
    digest = hmac.new(
        str(CLIENT_SECRET).encode('utf-8'),
        msg = str(msg).encode('utf-8'),
        digestmod=hashlib.sha256
    ).digest()
    hash = base64.b64encode(digest).decode()

    return hash

def initiate_auth(username, password):
    """Authenticate user/password with Cognito UserPool
    Args:
        username: Cognito userpool user name
        password: Cognito userpool user password
    Returns: Boto3 response
    """
    response = get_client().admin_initiate_auth(
        UserPoolId=USER_POOL_ID,
        ClientId=CLIENT_ID,
        AuthFlow='ADMIN_NO_SRP_AUTH',
        AuthParameters={
            'USERNAME': username,
            'SECRET_HASH': get_secret_hash(username),
            'PASSWORD': password
        },
        ClientMetadata={
            'username': username,
            'password': password
        }
    )
    return response

def refresh_auth(username, refresh_token):
    """Refresh tokens
    Args:
        refresh_token: Cognito userpool refresh token
    Returns: Boto3 response
    """
    response = get_client().admin_initiate_auth(
        USER_POOL_ID=USER_POOL_ID,
        ClientId=CLIENT_ID,
        AuthFlow='REFRESH_TOKEN_AUTH',
        AuthParameters={
            'REFRESH_TOKEN': refresh_token,
            'SECRET_HASH': get_secret_hash(username)
        }
    )
    return response

def main():
    response = initiate_auth(USERNAME, PASSWORD)

    id_token = response['AuthenticationResult']['IdToken']
    access_token = response['AuthenticationResult']['AccessToken']
    refresh_token = response['AuthenticationResult']['RefreshToken']
    
    response = refresh_auth(credential['username'], refresh_token)


if __name__ == '__main__':
    main()