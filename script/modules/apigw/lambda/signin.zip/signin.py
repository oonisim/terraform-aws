from __future__ import print_function
import boto3
import botocore.exceptions
import hmac
import hashlib
import base64
import json
import uuid
 
# MODIFY
USER_POOL_ID = 'us-east-1_6gfDXUjz2'
CLIENT_ID = '5ccudkmj2votruf37mbtcq8cmq'
CLIENT_SECRET = '12rehbv07sdn062lqpn5k4721slkipbs0cro2uleomavgupbk8d'

client = None

def get_secret_hash(username):
    msg = username + CLIENT_ID
    dig = hmac.new(str(CLIENT_SECRET).encode('utf-8'), 
        msg = str(msg).encode('utf-8'), digestmod=hashlib.sha256).digest()
    d2 = base64.b64encode(dig).decode()
    return d2

ERROR = 0
SUCCESS = 1
USER_EXISTS = 2
    
def initiate_auth(username, password):
    try:
        resp = client.admin_initiate_auth(
            UserPoolId=USER_POOL_ID,
            ClientId=CLIENT_ID,
            AuthFlow='ADMIN_NO_SRP_AUTH',
            AuthParameters={
                'USERNAME': username,
                'SECRET_HASH': get_secret_hash(username),
                'PASSWORD': password
            },
            ClientMetadata={
                'username': username,
                'password': password
            })
    except client.exceptions.NotAuthorizedException as e:
        return None, "The username or password is incorrect"
    except Exception as e:
        print(e)
        return None, "Unknown error"
    return resp, None

def lambda_handler(event, context):
    #--------------------------------------------------------------------------------
    # [Expected Lambda Integration type]
    # AWS_PROXY (Lambda Proxy Integration) where API GW relay the received Request Object to Lambda.
    # [Expected input format]
    # {u'body': u'{ \n "username": "masayuki.onishi@riotinto.com", \n "password": "Password"\n}',...}
    # The HTTP POST body is STRING, NOT JSON/Dictionary, hence needs to decode into JSON from String.
    # When testing from API Gateway, encoding Request Body field into 'body' element is done by API GW.
    #--------------------------------------------------------------------------------
    global client
    if client == None:
        client = boto3.client('cognito-idp')

    print("type of event")
    print(type(event))
    print(event)

    # Body is string, not JSON.
    body = json.loads(event['body'])
    print("type of body")
    print(type(body))
    print(body)

    username = body['username']
    password = body['password']

    user_id = str(uuid.uuid4())
    resp, msg = initiate_auth(username, password)
    if msg != None:
        return {'status': 'fail', 'msg': msg}
    id_token = resp['AuthenticationResult']['IdToken']
    print('id token: ' + id_token)
    #return {'status': 'success', 'id_token': id_token, 'user_id': user_id}

    response = {
       "Username" : username,
       "JWT_TOKEN": id_token
    }
    return {
        "statusCode": 200,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(response),
        "isBase64Encoded": False
    }
